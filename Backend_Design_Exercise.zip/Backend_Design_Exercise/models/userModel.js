// Mock users stored in memory
const users = [];

module.exports = users;
